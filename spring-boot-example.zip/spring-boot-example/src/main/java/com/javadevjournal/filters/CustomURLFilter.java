package com.javadevjournal.filters;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.javadevjournal.model.User;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class CustomURLFilter implements Filter {

    private static final Logger LOGGER = LoggerFactory.getLogger(CustomURLFilter.class);

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        LOGGER.info("########## Initiating CustomURLFilter filter ##########");
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {

        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;

        
        User user = new User();
        user.setClient_id(request.getHeader("client_id"));
    	user.setApp_id(request.getHeader("app_id"));
    	user.setUser_ip(request.getHeader("user_ip"));
    	user.setUser_agent(request.getHeader("user_agent"));
    	user.setGeolocation(request.getHeader("geolocation"));
    	user.setLog_datetime(request.getHeader("log_datetime"));
    	user.setLog_level(request.getHeader("log_level"));
    	user.setLog_type(request.getHeader("log_type"));
        System.out.println("user:"+user);
        LOGGER.info("This Filter is only called when request is mapped for /customer resource"+user);

        //call next filter in the filter chain
        filterChain.doFilter(request, response);
    }

    @Override
    public void destroy() {

    }
}
