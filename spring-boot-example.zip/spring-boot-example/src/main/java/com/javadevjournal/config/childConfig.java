package com.javadevjournal.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class childConfig extends AppConfig{

}
